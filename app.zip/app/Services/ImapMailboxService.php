<?php

namespace App\Services;

use RuntimeException;

class ImapMailboxService
{
    private mixed $connection = null;

    public function configured(): bool
    {
        return filled(setting('imap_host')) && filled(setting('mail_username')) && filled(setting('mail_password'));
    }

    public function inbox(int $page = 1, int $perPage = 25, ?string $search = null): array
    {
        $mailbox = $this->connect();
        $criteria = 'ALL';
        if (filled($search)) {
            $term = str_replace(['\\', '"'], ['\\\\', '\\"'], trim($search));
            $criteria = 'OR FROM "'.$term.'" SUBJECT "'.$term.'"';
        }

        $uids = imap_search($mailbox, $criteria, SE_UID) ?: [];
        rsort($uids, SORT_NUMERIC);
        $total = count($uids);
        $page = max(1, $page);
        $pageUids = array_slice($uids, ($page - 1) * $perPage, $perPage);
        $messages = [];

        foreach ($pageUids as $uid) {
            $overview = imap_fetch_overview($mailbox, (string) $uid, FT_UID)[0] ?? null;
            if (! $overview) continue;
            $messages[] = $this->overview($overview, (int) $uid);
        }

        return compact('messages', 'total', 'page', 'perPage');
    }

    public function message(int $uid): array
    {
        $mailbox = $this->connect();
        $overview = imap_fetch_overview($mailbox, (string) $uid, FT_UID)[0] ?? null;
        if (! $overview) throw new RuntimeException(__('Email message not found.'));

        $structure = imap_fetchstructure($mailbox, (string) $uid, FT_UID);
        $body = $structure ? $this->extractText($mailbox, $uid, $structure) : '';
        imap_setflag_full($mailbox, (string) $uid, '\\Seen', ST_UID);

        return array_merge($this->overview($overview, $uid), ['body' => trim($body)]);
    }

    public function delete(int $uid): void
    {
        $mailbox = $this->connect();
        if (! imap_delete($mailbox, (string) $uid, FT_UID)) {
            throw new RuntimeException(imap_last_error() ?: __('Unable to delete this email.'));
        }
        if (! imap_expunge($mailbox)) {
            throw new RuntimeException(imap_last_error() ?: __('Unable to finish deleting this email.'));
        }
    }

    public function close(): void
    {
        if ($this->connection) {
            imap_close($this->connection);
            $this->connection = null;
        }
    }

    private function connect(): mixed
    {
        if (! function_exists('imap_open')) {
            throw new RuntimeException(__('The PHP IMAP extension is not enabled on this server. Enable it from the hosting PHP extensions panel.'));
        }
        if (! $this->configured()) {
            throw new RuntimeException(__('Incoming mail is not configured. Complete Site Settings → Email first.'));
        }
        if ($this->connection) return $this->connection;

        $host = trim((string) setting('imap_host'));
        $port = (int) setting('imap_port', 993);
        $encryption = (string) setting('imap_encryption', 'ssl');
        $flags = '/imap'.($encryption !== 'none' ? '/'.$encryption : '');
        $path = '{'.$host.':'.$port.$flags.'}INBOX';
        $this->connection = @imap_open($path, (string) setting('mail_username'), (string) setting('mail_password'));

        if (! $this->connection) {
            $error = imap_last_error() ?: __('Unable to connect to the mailbox.');
            throw new RuntimeException($error);
        }

        return $this->connection;
    }

    private function overview(object $item, int $uid): array
    {
        $date = isset($item->date) ? date_create($item->date) : false;
        $addressList = isset($item->from) ? imap_rfc822_parse_adrlist((string) $item->from, '') : [];
        $address = $addressList[0] ?? null;
        $fromEmail = $address && ! empty($address->mailbox) && ! empty($address->host)
            ? $address->mailbox.'@'.$address->host
            : null;

        return [
            'uid' => $uid,
            'subject' => $this->decode((string) ($item->subject ?? __('No subject'))),
            'from' => $this->decode((string) ($item->from ?? __('Unknown sender'))),
            'from_email' => $fromEmail,
            'to' => $this->decode((string) ($item->to ?? '')),
            'date' => $date ?: null,
            'seen' => ! empty($item->seen),
            'size' => (int) ($item->size ?? 0),
            'message_id' => (string) ($item->message_id ?? ''),
        ];
    }

    private function decode(string $value): string
    {
        $parts = imap_mime_header_decode($value);
        return collect($parts)->map(fn ($part) => $part->text ?? '')->implode('');
    }

    private function extractText(mixed $mailbox, int $uid, object $structure, string $part = ''): string
    {
        if (! empty($structure->parts)) {
            $plain = '';
            $html = '';
            foreach ($structure->parts as $index => $child) {
                $number = $part === '' ? (string) ($index + 1) : $part.'.'.($index + 1);
                $text = $this->extractText($mailbox, $uid, $child, $number);
                if ((int) ($child->type ?? -1) === 0 && strtoupper((string) ($child->subtype ?? '')) === 'PLAIN') $plain .= $text;
                else $html .= $text;
            }
            return $plain !== '' ? $plain : $html;
        }

        if ((int) ($structure->type ?? -1) !== 0) return '';
        $raw = $part === '' ? imap_body($mailbox, (string) $uid, FT_UID) : imap_fetchbody($mailbox, (string) $uid, $part, FT_UID);
        $decoded = match ((int) ($structure->encoding ?? 0)) {
            3 => base64_decode($raw) ?: '',
            4 => quoted_printable_decode($raw),
            default => $raw,
        };
        return strtoupper((string) ($structure->subtype ?? '')) === 'HTML'
            ? html_entity_decode(strip_tags($decoded), ENT_QUOTES | ENT_HTML5, 'UTF-8')
            : $decoded;
    }
}
