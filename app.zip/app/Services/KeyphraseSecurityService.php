<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\URL;

class KeyphraseSecurityService
{
    public const ALLOWED_COUNTS = [12, 15, 18];

    public function normalize(string $phrase): string
    {
        return mb_strtolower(trim((string) preg_replace('/\s+/u', ' ', $phrase)));
    }

    public function words(string $phrase): array
    {
        $normalized = $this->normalize($phrase);

        return $normalized === '' ? [] : preg_split('/\s+/u', $normalized, -1, PREG_SPLIT_NO_EMPTY);
    }

    public function isValid(string $phrase, int $count): bool
    {
        $words = $this->words($phrase);

        return in_array($count, self::ALLOWED_COUNTS, true)
            && count($words) === $count
            && collect($words)->every(fn (string $word): bool => (bool) preg_match('/^[\pL][\pL\pM\'-]{1,31}$/u', $word));
    }

    public function pack(string $phrase, int $count): string
    {
        return 'keyphrase:'.$count.':'.Hash::make($this->normalize($phrase));
    }

    public function isKeyphraseSecret(?string $secret): bool
    {
        return is_string($secret) && str_starts_with($secret, 'keyphrase:');
    }

    public function count(?string $secret): ?int
    {
        if (! $this->isKeyphraseSecret($secret)) {
            return null;
        }

        return (int) explode(':', $secret, 3)[1];
    }

    public function verify(?string $secret, string $phrase): bool
    {
        if (! $this->isKeyphraseSecret($secret)) {
            return false;
        }

        [, , $hash] = explode(':', $secret, 3);

        return Hash::check($this->normalize($phrase), $hash);
    }

    public function fingerprint(User $user): string
    {
        return substr(hash_hmac('sha256', (string) $user->google2fa_secret, (string) config('app.key')), 0, 40);
    }

    public function recoveryUrl(User $user): string
    {
        return URL::signedRoute('user.password.keyphrase-recovery', [
            'user' => $user->id,
            'fingerprint' => $this->fingerprint($user),
        ]);
    }
}
