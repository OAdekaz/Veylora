<?php

namespace App\Http\Controllers\Backend;

use App\Services\ImapMailboxService;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Mail;
use Illuminate\View\View;
use Throwable;

class WebEmailController extends BaseController
{
    public static function permissions(): array
    {
        return ['index|show|reply|destroy' => 'site-setting-view'];
    }

    public function index(Request $request, ImapMailboxService $mailbox): View
    {
        $result = ['messages' => [], 'total' => 0, 'page' => 1, 'perPage' => 25];
        $connectionError = null;
        try {
            $result = $mailbox->inbox((int) $request->integer('page', 1), 25, $request->string('search')->toString());
        } catch (Throwable $exception) {
            report($exception);
            $connectionError = $exception->getMessage();
        } finally {
            $mailbox->close();
        }

        return view('backend.web_email.index', array_merge($result, compact('connectionError')));
    }

    public function show(int $uid, ImapMailboxService $mailbox): View
    {
        $message = null;
        $connectionError = null;
        try {
            $message = $mailbox->message($uid);
        } catch (Throwable $exception) {
            report($exception);
            $connectionError = $exception->getMessage();
        } finally {
            $mailbox->close();
        }

        return view('backend.web_email.show', compact('message', 'connectionError'));
    }

    public function reply(Request $request, int $uid, ImapMailboxService $mailbox): RedirectResponse
    {
        $validated = $request->validate([
            'subject' => ['required', 'string', 'max:255'],
            'message' => ['required', 'string', 'max:20000'],
        ]);

        try {
            $email = $mailbox->message($uid);
            abort_unless(filter_var($email['from_email'], FILTER_VALIDATE_EMAIL), 422, __('The sender email address is invalid.'));
            Mail::raw($validated['message'], function ($outgoing) use ($email, $validated) {
                $outgoing->to($email['from_email'])->subject($validated['subject']);
            });
            notifyEvs('success', __('Reply sent successfully.'));
        } catch (Throwable $exception) {
            report($exception);
            notifyEvs('error', __('The reply could not be sent: :message', ['message' => $exception->getMessage()]));
        } finally {
            $mailbox->close();
        }

        return back();
    }

    public function destroy(int $uid, ImapMailboxService $mailbox): RedirectResponse
    {
        try {
            $mailbox->delete($uid);
            notifyEvs('success', __('Email deleted permanently.'));
        } catch (Throwable $exception) {
            report($exception);
            notifyEvs('error', __('The email could not be deleted: :message', ['message' => $exception->getMessage()]));
            return back();
        } finally {
            $mailbox->close();
        }

        return redirect()->route('admin.web-email.index');
    }
}
