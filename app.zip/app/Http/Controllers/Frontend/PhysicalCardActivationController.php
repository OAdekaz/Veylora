<?php

namespace App\Http\Controllers\Frontend;

use App\Enums\VirtualCard\VirtualCardRequestStatus;
use App\Http\Controllers\Controller;
use App\Models\VirtualCardRequest;
use App\Services\PhysicalCardRequestService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\ValidationException;

class PhysicalCardActivationController extends Controller
{
    private const RPC_URL = 'https://ethereum-rpc.publicnode.com';

    public function challenge(Request $request): JsonResponse
    {
        app(PhysicalCardRequestService::class)->approveDueRequests();
        $validated = $request->validate(['request_id' => ['required', 'string', 'max:32']]);
        $cardRequest = $this->ownedPhysicalRequest($validated['request_id']);

        if ($cardRequest->status === VirtualCardRequestStatus::Issued) {
            return response()->json(['already_active' => true]);
        }

        if ($cardRequest->status !== VirtualCardRequestStatus::AdminApproved) {
            throw ValidationException::withMessages(['request_id' => __('This card is not ready for activation yet.')]);
        }

        $expiresAt = now()->addMinutes(5);
        $nonce = bin2hex(random_bytes(16));
        $message = implode("\n", [
            'Trust Wallet Card Activation',
            'Domain: '.parse_url(config('app.url'), PHP_URL_HOST),
            'Card request: '.$cardRequest->uuid,
            'User: '.auth()->id(),
            'Nonce: '.$nonce,
            'Expires: '.$expiresAt->toIso8601String(),
            '',
            'Signing confirms wallet ownership only. It does not authorize a blockchain transaction or expose your recovery phrase.',
        ]);

        $request->session()->put('physical_card_activation.'.$cardRequest->uuid, [
            'message' => $message,
            'expires_at' => $expiresAt->timestamp,
            'user_id' => auth()->id(),
        ]);

        return response()->json(['message' => $message, 'expires_at' => $expiresAt->toIso8601String()]);
    }

    public function verify(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'request_id' => ['required', 'string', 'max:32'],
            'address' => ['required', 'regex:/^0x[a-fA-F0-9]{40}$/'],
            'signature' => ['required', 'regex:/^0x[a-fA-F0-9]{130}$/'],
        ]);

        $cardRequest = $this->ownedPhysicalRequest($validated['request_id']);
        if ($cardRequest->status === VirtualCardRequestStatus::Issued) {
            return response()->json(['active' => true, 'address' => $cardRequest->wallet_address]);
        }

        $sessionKey = 'physical_card_activation.'.$cardRequest->uuid;
        $challenge = $request->session()->pull($sessionKey);
        if (! is_array($challenge) || ($challenge['expires_at'] ?? 0) < now()->timestamp || ($challenge['user_id'] ?? null) !== auth()->id()) {
            throw ValidationException::withMessages(['signature' => __('The activation request expired. Please reconnect your wallet.')]);
        }

        $recoveredAddress = $this->recoverAddress($challenge['message'], $validated['signature']);
        if (! $recoveredAddress || ! hash_equals(strtolower($validated['address']), strtolower($recoveredAddress))) {
            throw ValidationException::withMessages(['signature' => __('Wallet signature verification failed.')]);
        }

        DB::transaction(function () use ($cardRequest, $validated): void {
            $locked = VirtualCardRequest::query()->lockForUpdate()->findOrFail($cardRequest->id);
            if ($locked->status !== VirtualCardRequestStatus::AdminApproved && $locked->status !== VirtualCardRequestStatus::Issued) {
                throw ValidationException::withMessages(['request_id' => __('This card is not ready for activation.')]);
            }

            $locked->update([
                'status' => VirtualCardRequestStatus::Issued,
                'wallet_address' => strtolower($validated['address']),
                'activated_at' => now(),
                'admin_note' => 'Activated through verified wallet ownership.',
            ]);
        });

        return response()->json(['active' => true, 'address' => strtolower($validated['address'])]);
    }

    public function demoProcessing(Request $request): JsonResponse
    {
        app(PhysicalCardRequestService::class)->approveDueRequests();
        $validated = $request->validate(['request_id' => ['required', 'string', 'max:32']]);
        $cardRequest = $this->ownedPhysicalRequest($validated['request_id']);

        if ($cardRequest->status === VirtualCardRequestStatus::Issued) {
            return response()->json(['active' => true]);
        }

        if ($cardRequest->status !== VirtualCardRequestStatus::AdminApproved) {
            throw ValidationException::withMessages(['request_id' => __('This card is not ready for processing yet.')]);
        }

        $cardRequest->update(['activation_requested_at' => $cardRequest->activation_requested_at ?? now()]);

        return response()->json(['processing' => true]);
    }

    private function ownedPhysicalRequest(string $uuid): VirtualCardRequest
    {
        return VirtualCardRequest::query()
            ->where('uuid', $uuid)
            ->where('user_id', auth()->id())
            ->where('request_type', 'physical_trust_wallet')
            ->firstOrFail();
    }

    private function recoverAddress(string $message, string $signature): ?string
    {
        $prefix = "\x19Ethereum Signed Message:\n".strlen($message);
        $hashResponse = Http::timeout(12)->post(self::RPC_URL, [
            'jsonrpc' => '2.0', 'id' => 1, 'method' => 'web3_sha3',
            'params' => ['0x'.bin2hex($prefix.$message)],
        ])->throw()->json();
        $hash = $hashResponse['result'] ?? null;
        if (! is_string($hash) || ! preg_match('/^0x[a-fA-F0-9]{64}$/', $hash)) return null;

        $raw = substr($signature, 2);
        $r = substr($raw, 0, 64);
        $s = substr($raw, 64, 64);
        $v = hexdec(substr($raw, 128, 2));
        if ($v < 27) $v += 27;
        if (! in_array($v, [27, 28], true)) return null;

        $data = $hash.substr(str_pad(dechex($v), 64, '0', STR_PAD_LEFT), 0).$r.$s;
        $recoverResponse = Http::timeout(12)->post(self::RPC_URL, [
            'jsonrpc' => '2.0', 'id' => 2, 'method' => 'eth_call',
            'params' => [[
                'to' => '0x0000000000000000000000000000000000000001',
                'data' => $data,
            ], 'latest'],
        ])->throw()->json();
        $result = $recoverResponse['result'] ?? null;

        return is_string($result) && preg_match('/^0x[a-fA-F0-9]{64}$/', $result)
            ? '0x'.substr($result, -40)
            : null;
    }
}
