<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ContactController extends Controller
{
    /**
     * Handle Contact Form Submission.
     */
    public function submit(Request $request)
    {
        $validated = $request->validate([
            'website' => ['prohibited'],
            'name'    => ['required', 'string', 'max:255'],
            'email'   => ['required', 'email', 'max:255'],
            'phone'   => ['required', 'string', 'max:30'],
            'subject' => ['required', 'string', 'max:255'],
            'message' => ['required', 'string', 'max:5000'],
        ]);

        try {
            $recipient   = (string) setting('support_email', config('mail.from.address'));
            $fromAddress = (string) setting('email_from_address', config('mail.from.address'));
            $fromName    = (string) setting('email_from_name', setting('site_title', config('app.name')));

            Mail::send(['html' => 'emails.contact', 'text' => 'emails.contact-text'], [
                'name'    => $validated['name'],
                'email'   => $validated['email'],
                'phone'   => $validated['phone'],
                'subject' => $validated['subject'],
                'body'    => $validated['message'],
            ], function ($message) use ($validated, $recipient, $fromAddress, $fromName) {
                $message->to($recipient)
                    ->from($fromAddress, $fromName)
                    ->replyTo($validated['email'], $validated['name'])
                    ->returnPath($fromAddress)
                    ->subject(__('Veylora support request: :subject', ['subject' => $validated['subject']]));

                $headers = $message->getSymfonyMessage()->getHeaders();
                $headers->addTextHeader('X-Entity-Ref-ID', 'contact-'.bin2hex(random_bytes(10)));
                $headers->addTextHeader('X-Auto-Response-Suppress', 'OOF, AutoReply');
            });

            notifyEvs('success', __('Thank you! Your message has been sent successfully.'));

            return redirect()->back()->with('contact_success', __('Thank you! Your message has been sent successfully.'));

        } catch (\Exception $e) {
            notifyEvs('error', __('Something went wrong. Please try again later.'));

            return redirect()->back()->withInput()->with('contact_error', __('Something went wrong. Please try again later.'));
        }
    }
}
