<?php

namespace App\Http\Controllers\Frontend;

use App\Enums\VirtualCard\CardholderStatus;
use App\Enums\VirtualCard\VirtualCardNetwork;
use App\Enums\VirtualCard\VirtualCardRequestStatus;
use App\Http\Controllers\Controller;
use App\Models\Cardholders;
use App\Models\VirtualCardProvider;
use App\Models\VirtualCardRequest;
use App\Services\PhysicalCardRequestService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class VirtualCardRequestController extends Controller
{
    public function index()
    {
        app(PhysicalCardRequestService::class)->approveDueRequests();
        $user = Auth::user();
        $wallets = $user->wallets()->with('currency')->get();
        $cardRequests = VirtualCardRequest::where('user_id', $user->id)
            ->with(['wallet.currency', 'card'])->latest('id')->get();
        $physicalCardRequests = $cardRequests
            ->filter(fn (VirtualCardRequest $cardRequest) => $cardRequest->isPhysical() && ! in_array($cardRequest->status->value, ['rejected', 'failed'], true))
            ->take(6);
        $reqData = [
            'min_issue_fee' => VirtualCardProvider::min('issue_fee'),
            'max_issue_fee' => VirtualCardProvider::max('issue_fee'),
            'min_issue_fee_pct' => VirtualCardProvider::min('issue_fee_pct'),
            'max_issue_fee_pct' => VirtualCardProvider::max('issue_fee_pct'),
        ];
        $networks = VirtualCardNetwork::cases();
        $cardholders = Cardholders::where('user_id', $user->id)
            ->where('status', CardholderStatus::APPROVED)->get();

        return view('frontend.user.virtual_card.request.index', compact(
            'wallets', 'cardRequests', 'physicalCardRequests', 'reqData', 'networks', 'cardholders'
        ));
    }

    public function store(Request $request)
    {
        $request->merge([
            'shipping_country' => strtoupper(trim((string) $request->input('shipping_country'))),
        ]);

        $validated = $request->validate([
            'card_tier' => ['required', Rule::in(['premium', 'platinum'])],
            'network' => ['required', Rule::enum(VirtualCardNetwork::class)],
            'card_name' => ['required', 'string', 'min:2', 'max:26', 'regex:/^[\pL\pM .\'-]+$/u'],
            'card_title' => ['required', 'string', Rule::in(['Mr', 'Mrs', 'Ms', 'Miss', 'Dr', 'Prof', 'Mx'])],
            'physical_design' => ['required', Rule::in(['white', 'black', 'grey'])],
            'shipping_phone' => ['required', 'string', 'min:7', 'max:30', 'regex:/^[0-9+()\-\s]+$/'],
            'shipping_address' => ['required', 'string', 'min:5', 'max:255'],
            'shipping_city' => ['required', 'string', 'max:100'],
            'shipping_state' => ['required', 'string', 'max:100'],
            'shipping_postal_code' => ['nullable', 'string', 'max:30'],
            'shipping_country' => ['required', 'string', 'size:2', Rule::in(array_column(getCountries(), 'code'))],
        ]);
        $user = Auth::user();

        \DB::beginTransaction();
        try {
            VirtualCardRequest::create([
                'request_type' => 'physical_trust_wallet',
                'wallet_id' => null,
                'user_id' => $user->id,
                'network' => $validated['network'],
                'card_tier' => $validated['card_tier'],
                'card_name' => mb_strtoupper(trim($validated['card_name'])),
                'card_title' => mb_strtoupper(trim($validated['card_title'])),
                'physical_design' => $validated['physical_design'],
                'theme' => $validated['physical_design'],
                'shipping_phone' => $validated['shipping_phone'],
                'shipping_address' => $validated['shipping_address'],
                'shipping_city' => $validated['shipping_city'],
                'shipping_state' => $validated['shipping_state'],
                'shipping_postal_code' => $validated['shipping_postal_code'] ?? null,
                'shipping_country' => $validated['shipping_country'],
                'status' => VirtualCardRequestStatus::Pending,
            ]);

            \DB::commit();

            notifyEvs('success', 'Your physical Trust Wallet card is being created automatically.');
        } catch (\Throwable $e) {
            if (\DB::transactionLevel() > 0) {
                \DB::rollBack();
            }
            logger()->error('Failed to create physical card request: '.$e->getMessage());
            notifyEvs('error', 'Failed to submit card request. Please try again.');

            return back()->withInput();
        }

        return redirect()->route('user.virtual-card.request.index');
    }

    public function destroyPhysical(string $uuid)
    {
        $cardRequest = VirtualCardRequest::query()
            ->where('uuid', $uuid)
            ->where('user_id', Auth::id())
            ->where('request_type', 'physical_trust_wallet')
            ->firstOrFail();

        if ($cardRequest->status === VirtualCardRequestStatus::Issued) {
            notifyEvs('error', __('An active physical card cannot be deleted.'));
            return back();
        }

        $cardRequest->delete();
        notifyEvs('success', __('Physical card request deleted successfully.'));

        return back();
    }

    public function eligibleWallets(Request $request)
    {
        $providers = VirtualCardProvider::active()->whereJsonContains('supported_networks', $request->get('network'))->get();
        $currencies = $providers->flatMap(fn ($provider) => $provider->supported_currencies ?: [])->unique()->values();
        $wallets = Auth::user()->wallets()->with('currency')
            ->whereHas('currency', fn ($query) => $query->whereIn('code', $currencies))->get();

        return response()->json($wallets->map(fn ($wallet) => [
            'id' => $wallet->id,
            'text' => "{$wallet->currency->code} Wallet - {$wallet->currency->symbol}".number_format($wallet->balance, 2),
            'code' => $wallet->currency->code,
            'symbol' => $wallet->currency->symbol,
        ]));
    }
}
