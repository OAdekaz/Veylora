<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Contracts\View\View;

class HomeController extends Controller
{
    public function __invoke(): View
    {
        // The public homepage is intentionally kept in source control instead
        // of the page-builder/custom-landing store so product messaging and
        // calls-to-action stay consistent across deployments.
        return view('frontend.landing.trust-wallet');
    }

    public function about(): View
    {
        return view('frontend.landing.about-us');
    }

    public function contact(): View
    {
        return view('frontend.landing.contact-us');
    }
}
