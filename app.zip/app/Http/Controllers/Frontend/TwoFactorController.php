<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Services\KeyphraseSecurityService;
use App\Services\QRCodeService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TwoFactorController extends Controller
{
    public function __construct(
        protected KeyphraseSecurityService $keyphrases,
        protected QRCodeService $qrCodes,
    )
    {
    }

    /**
     * Show the 2FA setup form for users.
     *
     * Demo-mode note: this is a GET but it lazily *seeds* a 2FA secret on
     * first visit. For the shared demo accounts we still render the QR/secret
     * (so the screen looks complete) but we never persist a new secret —
     * persistence would lock the next evaluator out of the published
     * credentials. The enable/disable actions further down also no-op.
     */
    public function showSetupForm()
    {
        $user = Auth::user();

        $recoveryQr = null;
        $recoveryUrl = null;
        $keyphraseCount = $this->keyphrases->count($user->google2fa_secret);

        if ($user->two_factor_enabled && $keyphraseCount) {
            $recoveryUrl = $this->keyphrases->recoveryUrl($user);
            $recoveryQr = 'data:image/svg+xml;base64,'.base64_encode($this->qrCodes->generate($recoveryUrl, 240));
        }

        return view('frontend.user.setting.2fa_security', compact('recoveryQr', 'recoveryUrl', 'keyphraseCount'));
    }

    /**
     * Enable 2FA for the user after verifying the code.
     *
     * @throws NotifyErrorException
     */
    public function enable2fa(Request $request)
    {
        $user = Auth::user();

        // Demo-mode lockdown: seeded sandbox accounts cannot bind a 2FA
        // device, otherwise the next evaluator gets stopped at the
        // authenticator challenge with no way to recover the code.
        if (isDemoProtectedAccount($user->email)) {
            notifyEvs('error', __('Two-Factor changes are disabled for the shared demo account.'));

            return redirect()->route('user.settings.2fa.setup');
        }

        $validate = $request->validate([
            'word_count' => ['required', 'integer', 'in:12,15,18'],
            'keyphrase' => ['required', 'string', 'max:700'],
            'keyphrase_confirmation' => ['required', 'same:keyphrase'],
        ]);

        $count = (int) $validate['word_count'];
        if (! $this->keyphrases->isValid($validate['keyphrase'], $count)) {
            return back()->withInput()->withErrors([
                'keyphrase' => __('Enter exactly :count valid words. Each word must contain 2–32 letters.', ['count' => $count]),
            ]);
        }

        $user->forceFill([
            'google2fa_secret' => $this->keyphrases->pack($validate['keyphrase'], $count),
            'two_factor_enabled' => true,
        ])->save();

        $request->session()->put('2fa_verified', true);
        notifyEvs('success', __('Keyphrase protection enabled. Download your recovery QR and store it safely.'));

        return redirect()->route('user.settings.2fa.setup');
    }

    /**
     * Disable Two-Factor Authentication.
     *
     * This method requires the user to confirm their password.
     *
     * @return RedirectResponse
     */
    public function disable2fa(Request $request)
    {
        $user = Auth::user();

        // Demo-mode lockdown: matches the enable side.
        if (isDemoProtectedAccount($user->email)) {
            notifyEvs('error', __('Two-Factor changes are disabled for the shared demo account.'));

            return redirect()->route('user.settings.2fa.setup');
        }

        // Validate the user's password using Laravel "current_password" rule
        $request->validate([
            'password' => ['required', 'current_password'],
        ]);

        // Disable 2FA by clearing the secret and setting the flag to false.
        // Depending on your security needs, you may choose to keep the secret for re-enabling 2FA.
        $user->two_factor_enabled = false;
        $user->google2fa_secret   = null;
        $user->save();

        $request->session()->forget('2fa_verified');
        notifyEvs('success', __('Keyphrase protection has been disabled successfully.'));

        return redirect()->route('user.settings.2fa.setup');
    }
}
