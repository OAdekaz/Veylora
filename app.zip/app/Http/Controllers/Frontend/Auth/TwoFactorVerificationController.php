<?php

namespace App\Http\Controllers\Frontend\Auth;

use App\Http\Controllers\Controller;
use App\Services\KeyphraseSecurityService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TwoFactorVerificationController extends Controller
{
    public function __construct(protected KeyphraseSecurityService $keyphrases)
    {
    }

    public function twoFactorChallenge()
    {
        return view(themedView('frontend.auth.two-factor-challenge'));
    }

    public function twoFactorAuthenticate(Request $request)
    {
        $request->validate([
            'keyphrase' => ['required', 'string', 'max:700'],
        ]);

        // Get the authenticated user
        $user = Auth::user();

        if ($this->keyphrases->verify($user->google2fa_secret, $request->input('keyphrase'))) {
            // If the code is correct, set a session flag for 2FA verification
            $request->session()->put('2fa_verified', true);

            // Redirect to the user dashboard
            return redirect()->route('user.dashboard');
        }

        // If verification fails, redirect back with an error message
        return redirect()->back()->withErrors([
            'keyphrase' => __('The keyphrase is incorrect.'),
        ]);
    }
}
